
/**
 * The wrapper of password and name
 * **/

public class NamePassword {
	String name;
	String password;
	NamePassword(String name,String password){
		this.name=name;
		this.password=password;
	}
}
